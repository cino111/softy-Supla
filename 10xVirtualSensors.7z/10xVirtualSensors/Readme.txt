Modu� dodajesz do Clud-a r�cznie.

Strona konfiguracyjna: 192.168.4.1


Ustawienia GPIO:


CONFIG_PIN        2xreset

Kolejne wej�cie w tryb Config - 2xreset
Parametry wgrywania:

CrystalFreq      26M
SPI SPEED        40 MHz
SPI MODE         DOUT
BAUDRATE         115200
FLASH SIZE       32-C1Mbit (4MByte)

10xVirtualSensors_4M_DOUT_0x00000.bin -----------------> 0x00000
