Button GPIO12
Zielona dioda GPIO13
Relay GPIO4

CrystalFreq      26M
SPI SPEED        80 MHz
SPI MODE         DOUT
BAUDRATE         115200
FLASH SIZE       32Mbit (4MByte)


0x00000