Modu� dodajesz do Clud-a r�cznie.

Strona konfiguracyjna: 192.168.4.1
Wybieramy przycisk MONOSTABILNY


Ustawienia GPIO:


CONFIG_PIN         0/ j4
Relay_PIN	  12/ j3
DS_PIN             3/ j10(RX)
DHT22_PIN         13/ j5
GND		      j2
3,3V		      j1


Kolejne wej�cie w tryb Config - GPIO0 do masy na 5s (przycisk na Sonoff)
Parametry wgrywania w nazwie pliku czyli:

CrystalFreq      26M
SPI SPEED        40 MHz
SPI MODE         DOUT
BAUDRATE         115200
FLASH SIZE       Mbit (1MByte)

Sonoff_S26_Relay_2xds18b20.bin -----------------> 0x00000

