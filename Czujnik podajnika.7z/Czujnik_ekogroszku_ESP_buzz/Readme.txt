Modu� dodajesz do Clud-a r�cznie.

Strona konfiguracyjna: 192.168.4.1


Ustawienia GPIO:


CONFIG_PIN        0
HC-SR04 TIG_PIN   12
HC-SR04 ECHO_PIN  13
DS_PIN            4
Relay_PIN	  5
buzzer_PIN	  14
Kolejne wej�cie w tryb Config - GPIO0 do masy na 5s
Parametry wgrywania w nazwie pliku czyli:

CrystalFreq      26M
SPI SPEED        40 MHz
SPI MODE         DOUT
BAUDRATE         115200
FLASH SIZE       32Mbit (4MByte)

Supla_cz_ekogroszku_4M_DOUT_0x00000.bin -----------------> 0x00000

lub wgrywasz bezpo�rednio z Arduino Ide - https://forum.supla.org/viewtopic.php?f=23&t=3559 